﻿namespace APPCALC
{
    partial class FrmForm1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbutton1 = new System.Windows.Forms.Button();
            this.btnbutton2 = new System.Windows.Forms.Button();
            this.btnbutton3 = new System.Windows.Forms.Button();
            this.btnbutton4 = new System.Windows.Forms.Button();
            this.btnbutton5 = new System.Windows.Forms.Button();
            this.btnbutton6 = new System.Windows.Forms.Button();
            this.btnbutton7 = new System.Windows.Forms.Button();
            this.btnbutton8 = new System.Windows.Forms.Button();
            this.btnbutton9 = new System.Windows.Forms.Button();
            this.btnbutton10 = new System.Windows.Forms.Button();
            this.btnbutton11 = new System.Windows.Forms.Button();
            this.btnbutton12 = new System.Windows.Forms.Button();
            this.btnbutton13 = new System.Windows.Forms.Button();
            this.btnbutton14 = new System.Windows.Forms.Button();
            this.btnbutton15 = new System.Windows.Forms.Button();
            this.btnbutton16 = new System.Windows.Forms.Button();
            this.btnbutton17 = new System.Windows.Forms.Button();
            this.btnbutton18 = new System.Windows.Forms.Button();
            this.txttextBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnbutton1
            // 
            this.btnbutton1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton1.Location = new System.Drawing.Point(50, 364);
            this.btnbutton1.Name = "btnbutton1";
            this.btnbutton1.Size = new System.Drawing.Size(44, 42);
            this.btnbutton1.TabIndex = 0;
            this.btnbutton1.Text = "1";
            this.btnbutton1.UseVisualStyleBackColor = false;
            // 
            // btnbutton2
            // 
            this.btnbutton2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton2.Location = new System.Drawing.Point(100, 364);
            this.btnbutton2.Name = "btnbutton2";
            this.btnbutton2.Size = new System.Drawing.Size(45, 42);
            this.btnbutton2.TabIndex = 1;
            this.btnbutton2.Text = "2";
            this.btnbutton2.UseVisualStyleBackColor = false;
            this.btnbutton2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnbutton3
            // 
            this.btnbutton3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton3.Location = new System.Drawing.Point(151, 364);
            this.btnbutton3.Name = "btnbutton3";
            this.btnbutton3.Size = new System.Drawing.Size(46, 42);
            this.btnbutton3.TabIndex = 2;
            this.btnbutton3.Text = "3";
            this.btnbutton3.UseVisualStyleBackColor = false;
            // 
            // btnbutton4
            // 
            this.btnbutton4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton4.Location = new System.Drawing.Point(49, 317);
            this.btnbutton4.Name = "btnbutton4";
            this.btnbutton4.Size = new System.Drawing.Size(45, 41);
            this.btnbutton4.TabIndex = 3;
            this.btnbutton4.Text = "4";
            this.btnbutton4.UseVisualStyleBackColor = false;
            // 
            // btnbutton5
            // 
            this.btnbutton5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton5.Location = new System.Drawing.Point(100, 317);
            this.btnbutton5.Name = "btnbutton5";
            this.btnbutton5.Size = new System.Drawing.Size(45, 41);
            this.btnbutton5.TabIndex = 4;
            this.btnbutton5.Text = "5";
            this.btnbutton5.UseVisualStyleBackColor = false;
            // 
            // btnbutton6
            // 
            this.btnbutton6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton6.Location = new System.Drawing.Point(151, 317);
            this.btnbutton6.Name = "btnbutton6";
            this.btnbutton6.Size = new System.Drawing.Size(46, 39);
            this.btnbutton6.TabIndex = 5;
            this.btnbutton6.Text = "6";
            this.btnbutton6.UseVisualStyleBackColor = false;
            // 
            // btnbutton7
            // 
            this.btnbutton7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton7.Location = new System.Drawing.Point(49, 277);
            this.btnbutton7.Name = "btnbutton7";
            this.btnbutton7.Size = new System.Drawing.Size(45, 34);
            this.btnbutton7.TabIndex = 6;
            this.btnbutton7.Text = "7";
            this.btnbutton7.UseVisualStyleBackColor = false;
            this.btnbutton7.Click += new System.EventHandler(this.btnbutton7_Click);
            // 
            // btnbutton8
            // 
            this.btnbutton8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton8.Location = new System.Drawing.Point(100, 277);
            this.btnbutton8.Name = "btnbutton8";
            this.btnbutton8.Size = new System.Drawing.Size(45, 37);
            this.btnbutton8.TabIndex = 7;
            this.btnbutton8.Text = "8";
            this.btnbutton8.UseVisualStyleBackColor = false;
            this.btnbutton8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnbutton9
            // 
            this.btnbutton9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton9.Location = new System.Drawing.Point(151, 277);
            this.btnbutton9.Name = "btnbutton9";
            this.btnbutton9.Size = new System.Drawing.Size(46, 37);
            this.btnbutton9.TabIndex = 8;
            this.btnbutton9.Text = "9";
            this.btnbutton9.UseVisualStyleBackColor = false;
            this.btnbutton9.Click += new System.EventHandler(this.button9_Click);
            // 
            // btnbutton10
            // 
            this.btnbutton10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton10.Location = new System.Drawing.Point(203, 276);
            this.btnbutton10.Name = "btnbutton10";
            this.btnbutton10.Size = new System.Drawing.Size(46, 37);
            this.btnbutton10.TabIndex = 9;
            this.btnbutton10.Text = "/";
            this.btnbutton10.UseVisualStyleBackColor = false;
            // 
            // btnbutton11
            // 
            this.btnbutton11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton11.Location = new System.Drawing.Point(203, 319);
            this.btnbutton11.Name = "btnbutton11";
            this.btnbutton11.Size = new System.Drawing.Size(46, 37);
            this.btnbutton11.TabIndex = 10;
            this.btnbutton11.Text = "*";
            this.btnbutton11.UseVisualStyleBackColor = false;
            this.btnbutton11.Click += new System.EventHandler(this.button11_Click);
            // 
            // btnbutton12
            // 
            this.btnbutton12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton12.Location = new System.Drawing.Point(203, 369);
            this.btnbutton12.Name = "btnbutton12";
            this.btnbutton12.Size = new System.Drawing.Size(46, 37);
            this.btnbutton12.TabIndex = 11;
            this.btnbutton12.Text = "-";
            this.btnbutton12.UseVisualStyleBackColor = false;
            // 
            // btnbutton13
            // 
            this.btnbutton13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton13.Location = new System.Drawing.Point(50, 412);
            this.btnbutton13.Name = "btnbutton13";
            this.btnbutton13.Size = new System.Drawing.Size(95, 37);
            this.btnbutton13.TabIndex = 12;
            this.btnbutton13.Text = "0";
            this.btnbutton13.UseVisualStyleBackColor = false;
            // 
            // btnbutton14
            // 
            this.btnbutton14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton14.Location = new System.Drawing.Point(151, 412);
            this.btnbutton14.Name = "btnbutton14";
            this.btnbutton14.Size = new System.Drawing.Size(46, 37);
            this.btnbutton14.TabIndex = 13;
            this.btnbutton14.Text = ",";
            this.btnbutton14.UseVisualStyleBackColor = false;
            // 
            // btnbutton15
            // 
            this.btnbutton15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton15.Location = new System.Drawing.Point(203, 412);
            this.btnbutton15.Name = "btnbutton15";
            this.btnbutton15.Size = new System.Drawing.Size(46, 37);
            this.btnbutton15.TabIndex = 14;
            this.btnbutton15.Text = "+";
            this.btnbutton15.UseVisualStyleBackColor = false;
            // 
            // btnbutton16
            // 
            this.btnbutton16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnbutton16.Location = new System.Drawing.Point(255, 369);
            this.btnbutton16.Name = "btnbutton16";
            this.btnbutton16.Size = new System.Drawing.Size(46, 80);
            this.btnbutton16.TabIndex = 15;
            this.btnbutton16.Text = " =";
            this.btnbutton16.UseVisualStyleBackColor = false;
            this.btnbutton16.Click += new System.EventHandler(this.button16_Click);
            // 
            // btnbutton17
            // 
            this.btnbutton17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton17.Location = new System.Drawing.Point(255, 276);
            this.btnbutton17.Name = "btnbutton17";
            this.btnbutton17.Size = new System.Drawing.Size(46, 40);
            this.btnbutton17.TabIndex = 16;
            this.btnbutton17.Text = "%";
            this.btnbutton17.UseVisualStyleBackColor = false;
            this.btnbutton17.Click += new System.EventHandler(this.button17_Click);
            // 
            // btnbutton18
            // 
            this.btnbutton18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnbutton18.Location = new System.Drawing.Point(255, 322);
            this.btnbutton18.Name = "btnbutton18";
            this.btnbutton18.Size = new System.Drawing.Size(46, 39);
            this.btnbutton18.TabIndex = 17;
            this.btnbutton18.Text = "1/x";
            this.btnbutton18.UseVisualStyleBackColor = false;
            // 
            // txttextBox1
            // 
            this.txttextBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txttextBox1.Location = new System.Drawing.Point(49, 115);
            this.txttextBox1.Multiline = true;
            this.txttextBox1.Name = "txttextBox1";
            this.txttextBox1.Size = new System.Drawing.Size(391, 155);
            this.txttextBox1.TabIndex = 18;
            this.txttextBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // FrmForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(800, 593);
            this.Controls.Add(this.txttextBox1);
            this.Controls.Add(this.btnbutton18);
            this.Controls.Add(this.btnbutton17);
            this.Controls.Add(this.btnbutton16);
            this.Controls.Add(this.btnbutton15);
            this.Controls.Add(this.btnbutton14);
            this.Controls.Add(this.btnbutton13);
            this.Controls.Add(this.btnbutton12);
            this.Controls.Add(this.btnbutton11);
            this.Controls.Add(this.btnbutton10);
            this.Controls.Add(this.btnbutton9);
            this.Controls.Add(this.btnbutton8);
            this.Controls.Add(this.btnbutton7);
            this.Controls.Add(this.btnbutton6);
            this.Controls.Add(this.btnbutton5);
            this.Controls.Add(this.btnbutton4);
            this.Controls.Add(this.btnbutton3);
            this.Controls.Add(this.btnbutton2);
            this.Controls.Add(this.btnbutton1);
            this.Name = "FrmForm1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbutton1;
        private System.Windows.Forms.Button btnbutton2;
        private System.Windows.Forms.Button btnbutton3;
        private System.Windows.Forms.Button btnbutton4;
        private System.Windows.Forms.Button btnbutton5;
        private System.Windows.Forms.Button btnbutton6;
        private System.Windows.Forms.Button btnbutton7;
        private System.Windows.Forms.Button btnbutton8;
        private System.Windows.Forms.Button btnbutton9;
        private System.Windows.Forms.Button btnbutton10;
        private System.Windows.Forms.Button btnbutton11;
        private System.Windows.Forms.Button btnbutton12;
        private System.Windows.Forms.Button btnbutton13;
        private System.Windows.Forms.Button btnbutton14;
        private System.Windows.Forms.Button btnbutton15;
        private System.Windows.Forms.Button btnbutton16;
        private System.Windows.Forms.Button btnbutton17;
        private System.Windows.Forms.Button btnbutton18;
        private System.Windows.Forms.TextBox txttextBox1;
    }
}

