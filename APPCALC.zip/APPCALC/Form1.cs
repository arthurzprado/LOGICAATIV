﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APPCALC
{
    public partial class FrmForm1 : Form
    {
        public FrmForm1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("2");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("9");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("11");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            MessageBox.Show("total");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            MessageBox.Show("17");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("");
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            MessageBox.Show("8");
        }

        private void btnbutton7_Click(object sender, EventArgs e)
        {

        }
    }
}
